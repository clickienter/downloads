use crate::solana_utils::SolanaRpcClient;
use anyhow::{Context, Result};
use orca_whirlpools::{
    close_position_instructions, fetch_positions_for_owner, open_position_instructions, set_funder,
    swap_instructions, IncreaseLiquidityParam, PositionOrBundle,
};
use orca_whirlpools_client::{Whirlpool, WHIRLPOOL_ID};
use orca_whirlpools_core::sqrt_price_to_price;
use solana_client::nonblocking::rpc_client::RpcClient;
use solana_client::rpc_request::TokenAccountsFilter;
use solana_sdk::{
    commitment_config::CommitmentLevel,
    program_pack::Pack,
    pubkey::Pubkey,
    signature::{Signature, Signer},
    transaction::Transaction,
};
use spl_token_2022::state::Mint;
use std::collections::HashMap;
use std::str::FromStr;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::Mutex;
use tokio::time::sleep;
use tokio_retry::strategy::ExponentialBackoff;
use tokio_retry::Retry;

const PROGRAM_ID: Pubkey = Pubkey::new_from_array([
    0x6e, 0xeb, 0x65, 0x4a, 0x8e, 0x36, 0xe7, 0x49, 0xd0, 0x8f, 0xb8, 0x33, 0x5c, 0xd3, 0xa8, 0xea,
    0x6f, 0x73, 0xcc, 0x37, 0x11, 0x6f, 0x2e, 0xc1, 0x9b, 0x9e, 0x99, 0x7e, 0x58, 0x6b, 0x9b, 0x9c,
]);

fn get_position_address(position_mint: &Pubkey) -> Result<(Pubkey, u8), anyhow::Error> {
    let seeds = &[b"position", position_mint.as_ref()];

    Pubkey::try_find_program_address(seeds, &WHIRLPOOL_ID).ok_or(anyhow::anyhow!("Invalid Seeds"))
}

pub async fn fetch_mint(
    rpc: &Arc<RpcClient>,
    mint_address: &Pubkey,
    cache: &Mutex<HashMap<Pubkey, Mint>>,
) -> Result<Mint> {
    let mut cache_lock = cache.lock().await;
    if let Some(mint) = cache_lock.get(mint_address) {
        return Ok(mint.clone());
    }

    let mint_account = rpc
        .get_account(mint_address)
        .await
        .with_context(|| format!("Failed to fetch account data for mint: {}", mint_address))?;

    let mint = Mint::unpack(&mint_account.data)
        .with_context(|| format!("Failed to unpack mint data for: {}", mint_address))?;

    cache_lock.insert(*mint_address, mint.clone());
    Ok(mint)
}

#[derive(Clone)]
pub struct Position {
    pub lower_price: f64,
    pub upper_price: f64,
    #[allow(dead_code)]
    pub center_price: f64,
    pub mint_address: Pubkey,
    #[allow(dead_code)]
    pub address: Pubkey,
    pub tick_lower_index: i32,
    pub tick_upper_index: i32,
    #[allow(dead_code)]
    pub liquidity: u128,
}

pub struct PositionManager {
    pub client: SolanaRpcClient,
    wallet: Box<dyn Signer>,
    pool_address: Pubkey,
    position: Option<Position>,
    token_mint_a: Pubkey,
    token_mint_b: Pubkey,
    token_mint_a_decimals: u8,
    token_mint_b_decimals: u8,
    #[allow(dead_code)]
    mint_cache: Mutex<HashMap<Pubkey, Mint>>,
}

impl PositionManager {
    pub async fn new(
        client: SolanaRpcClient,
        wallet: Box<dyn Signer>,
        pool_address: Pubkey,
    ) -> Result<Self> {
        set_funder(wallet.pubkey()).map_err(|e| anyhow::anyhow!("Failed to set funder: {}", e))?;

        // Get pool account with better error handling
        println!("Fetching whirlpool account data for {}", pool_address);
        let whirlpool_account = client
            .rpc
            .get_account(&pool_address)
            .await
            .map_err(|e| anyhow::anyhow!("Failed to fetch whirlpool account: {}", e))?;

        println!("Account data size: {} bytes", whirlpool_account.data.len());

        // Verify this is actually a Whirlpool account
        let whirlpool = match Whirlpool::from_bytes(&whirlpool_account.data) {
            Ok(w) => {
                println!("Successfully deserialized Whirlpool data");
                w
            }
            Err(e) => {
                println!("Error deserializing Whirlpool: {}", e);
                println!("This likely means the address doesn't point to a valid Whirlpool pool");
                println!("Account owner: {}", whirlpool_account.owner);
                println!("Expected Whirlpool Program ID: {}", PROGRAM_ID);
                return Err(anyhow::anyhow!("Failed to deserialize Whirlpool data: {}. Check that this address is a valid Whirlpool pool on the selected network.", e));
            }
        };

        println!("Fetching token mint info");
        let mint_cache = Mutex::new(HashMap::new());

        // Fetch token mint A with error handling
        println!("Fetching token mint A: {}", whirlpool.token_mint_a);
        let token_mint_a = match fetch_mint(&client.rpc, &whirlpool.token_mint_a, &mint_cache).await
        {
            Ok(mint) => {
                println!(
                    "Token A mint fetched successfully: decimals={}",
                    mint.decimals
                );
                mint
            }
            Err(e) => {
                println!("Error fetching token A mint: {}", e);
                return Err(anyhow::anyhow!("Failed to fetch token A mint: {}", e));
            }
        };

        // Fetch token mint B with error handling
        println!("Fetching token mint B: {}", whirlpool.token_mint_b);
        let token_mint_b = match fetch_mint(&client.rpc, &whirlpool.token_mint_b, &mint_cache).await
        {
            Ok(mint) => {
                println!(
                    "Token B mint fetched successfully: decimals={}",
                    mint.decimals
                );
                mint
            }
            Err(e) => {
                println!("Error fetching token B mint: {}", e);
                return Err(anyhow::anyhow!("Failed to fetch token B mint: {}", e));
            }
        };

        Ok(PositionManager {
            client,
            wallet,
            pool_address,
            position: None,
            token_mint_a: whirlpool.token_mint_a,
            token_mint_b: whirlpool.token_mint_b,
            token_mint_a_decimals: token_mint_a.decimals,
            token_mint_b_decimals: token_mint_b.decimals,
            mint_cache,
        })
    }

    pub async fn get_current_price(&self) -> Result<f64> {
        let whirlpool_account = self.client.rpc.get_account(&self.pool_address).await?;
        let whirlpool = Whirlpool::from_bytes(&whirlpool_account.data)
            .map_err(|e| anyhow::anyhow!("Failed to deserialize Whirlpool: {}", e))?;
        Ok(sqrt_price_to_price(
            whirlpool.sqrt_price,
            self.token_mint_a_decimals,
            self.token_mint_b_decimals,
        ))
    }

    pub async fn get_whirlpool(&self) -> Result<Whirlpool> {
        let whirlpool_account = self.client.rpc.get_account(&self.pool_address).await?;
        Whirlpool::from_bytes(&whirlpool_account.data)
            .map_err(|e| anyhow::anyhow!("Failed to deserialize Whirlpool: {}", e))
    }

    pub async fn get_wallet_balance(&self) -> Result<u64> {
        let sol_mint = Pubkey::from_str("So11111111111111111111111111111111111111112")?;
        let sol_balance = self.get_balance(sol_mint).await?;
        let usdc_balance = self.get_usdc_balance().await?;

        Ok(sol_balance + usdc_balance)
    }

    pub async fn get_usdc_balance(&self) -> Result<u64> {
        let current_price = self.get_current_price().await?;
        let mut usdc_balance = self.get_balance(self.token_mint_b).await?;
        println!("Usdc balance: {}", usdc_balance);
        usdc_balance =
            ((usdc_balance as f64 / 1_000_000.0 / current_price) * 1_000_000_000.0) as u64;
        Ok(usdc_balance)
    }

    pub async fn get_balance(&self, token_mint: Pubkey) -> Result<u64> {
        use std::time::Duration;
        use tokio_retry::strategy::ExponentialBackoff;
        use tokio_retry::Retry;

        // Create a retry strategy with exponential backoff
        let retry_strategy = ExponentialBackoff::from_millis(500)
            .max_delay(Duration::from_secs(3))
            .take(3); // Try up to 3 times

        // Special case for SOL (native token)
        let sol_mint = Pubkey::from_str("So11111111111111111111111111111111111111112")?;

        if token_mint == sol_mint {
            // Check native SOL balance directly with retries
            return Retry::spawn(retry_strategy, || async {
                self.get_native_sol_balance()
                    .await
                    .map_err(|e| anyhow::anyhow!("Failed to get native SOL balance: {}", e))
            })
            .await;
        }

        // For other tokens, check token accounts with retries
        Retry::spawn(retry_strategy, || async {
            let token_accounts = self
                .client
                .rpc
                .get_token_accounts_by_owner(
                    &self.wallet.pubkey(),
                    TokenAccountsFilter::Mint(token_mint),
                )
                .await
                .map_err(|e| anyhow::anyhow!("Failed to get token accounts: {}", e))?;

            if let Some(account) = token_accounts.first() {
                let account_pubkey = Pubkey::from_str(&account.pubkey)
                    .map_err(|e| anyhow::anyhow!("Failed to parse token account pubkey: {}", e))?;

                let balance = self
                    .client
                    .rpc
                    .get_token_account_balance(&account_pubkey)
                    .await
                    .map_err(|e| anyhow::anyhow!("Failed to get token account balance: {}", e))?;

                Ok(balance
                    .amount
                    .parse::<u64>()
                    .map_err(|e| anyhow::anyhow!("Failed to parse token balance: {}", e))?)
            } else {
                println!("No token account found for mint: {}", token_mint);
                Ok(0)
            }
        })
        .await
    }

    pub async fn swap_tokens(
        &self,
        amount: u64,
        from_mint: Pubkey,
        to_mint: Pubkey,
        exact_out: bool,
    ) -> Result<Signature> {
        use solana_client::rpc_config::RpcSendTransactionConfig;
        use solana_sdk::commitment_config::CommitmentLevel;
        use solana_sdk::compute_budget::ComputeBudgetInstruction;
        use solana_sdk::message::Message;
        use tokio::time::{sleep, Duration, Instant};

        let sol_mint = Pubkey::from_str("So11111111111111111111111111111111111111112")?;

        // Use higher slippage tolerance (3%) when swapping to SOL, as SOL price can be volatile
        let slippage_tolerance =Some(100);

        println!(
            "Preparing to swap {} from {} to {} (slippage: {}%)",
            amount as f64
                / if from_mint == sol_mint {
                    1_000_000_000.0
                } else {
                    1_000_000.0
                },
            from_mint,
            to_mint,
            slippage_tolerance.unwrap_or(100) as f64 / 100.0
        );

        let side = if exact_out {
            orca_whirlpools::SwapType::ExactOut
        } else {
            orca_whirlpools::SwapType::ExactIn
        };
        let mint = if exact_out { to_mint } else { from_mint };

        // 1. Get swap instructions from SDK
        println!("Retrieving swap instructions...");
        let swap_result = swap_instructions(
            &self.client.rpc,
            self.pool_address,
            amount,
            mint,
            side,
            slippage_tolerance,
            Some(self.wallet.pubkey()),
        )
        .await
        .map_err(|e| anyhow::anyhow!("Swap instruction error: {}", e))?;

        println!(
            "Got swap instructions. Number of instructions: {}",
            swap_result.instructions.len()
        );
        println!("Quote estimated token out: {:?}", swap_result.quote);

        // Create message from instructions
        let message = Message::new(&swap_result.instructions, Some(&self.wallet.pubkey()));

        // 2. Prepare signers
        let mut signers: Vec<&dyn Signer> = vec![self.wallet.as_ref()];

        // Add any additional signers from the SDK result
        signers.extend(
            swap_result
                .additional_signers
                .iter()
                .map(|kp| kp as &dyn Signer),
        );

        println!("Using {} signers for transaction", signers.len());

        // Set up retry parameters
        let max_retries = 5;
        let base_backoff_ms = 1000; // Start with 1 second
        let max_backoff_ms = 15000; // Max 15 seconds
        let transaction_timeout = Duration::from_secs(90);

        for attempt in 0..max_retries {
            if attempt > 0 {
                println!(
                    "Retry attempt {}/{} for swap transaction",
                    attempt, max_retries
                );
            }

            // 3. Get latest blockhash
            let recent_blockhash = self.client.rpc.get_latest_blockhash().await?;

            // 4. Create transaction for simulation
            let transaction = Transaction::new(&signers, message.clone(), recent_blockhash);

            // 5. Simulate transaction to get compute units
            println!("Simulating transaction to determine compute units...");
            let simulated_transaction = match self
                .client
                .rpc
                .simulate_transaction(&transaction)
                .await
            {
                Ok(sim) => {
                    if let Some(err) = &sim.value.err {
                        println!("Transaction simulation failed: {:?}", err);
                        println!("Logs: {:?}", sim.value.logs);

                        // Check for specific errors that warrant retry
                        let err_str = format!("{:?}", err);
                        if err_str.contains("429") || err_str.contains("Too Many Requests") {
                            let backoff =
                                Self::calculate_backoff(attempt, base_backoff_ms, max_backoff_ms);
                            println!(
                                "Rate limit hit during simulation. Retrying in {}ms",
                                backoff
                            );
                            sleep(Duration::from_millis(backoff)).await;
                            continue;
                        }

                        // Some errors mean token account needs to be created
                        if err_str.contains("Account does not exist")
                            && to_mint
                                != Pubkey::from_str("So11111111111111111111111111111111111111112")?
                        {
                            println!(
                                "Token account may not exist. Creating token account for {}",
                                to_mint
                            );
                            match self.create_token_account_if_needed(to_mint).await {
                                Ok(_) => {
                                    println!("Token account created or verified. Retrying swap...");
                                    // Apply a short wait after account creation
                                    sleep(Duration::from_millis(1000)).await;
                                    continue;
                                }
                                Err(create_err) => {
                                    println!("Failed to create token account: {}", create_err);
                                    // Apply backoff and retry from the beginning
                                    let backoff = Self::calculate_backoff(
                                        attempt,
                                        base_backoff_ms,
                                        max_backoff_ms,
                                    );
                                    sleep(Duration::from_millis(backoff)).await;
                                    continue;
                                }
                            }
                        }

                        return Err(anyhow::anyhow!("Transaction simulation failed: {:?}", err));
                    }
                    sim
                }
                Err(e) => {
                    // Check if this is a rate limit error
                    if e.to_string().contains("429") || e.to_string().contains("Too Many Requests")
                    {
                        let backoff =
                            Self::calculate_backoff(attempt, base_backoff_ms, max_backoff_ms);
                        println!(
                            "Rate limit hit during simulation. Retrying in {}ms",
                            backoff
                        );
                        sleep(Duration::from_millis(backoff)).await;
                        continue;
                    }

                    println!("Failed to simulate transaction: {}", e);
                    // For other errors, use a shorter backoff
                    sleep(Duration::from_millis((attempt as u64 + 1) * 500)).await;
                    continue;
                }
            };

            // 6. Create final transaction with compute budget instructions
            let mut all_instructions = vec![];

            // Add compute budget instructions if simulation provided units consumed
            if let Some(units_consumed) = simulated_transaction.value.units_consumed {
                let units_consumed_safe = units_consumed as u32 + 100_000;
                println!("Adding compute budget limit: {} units", units_consumed_safe);
                let compute_limit_instruction =
                    ComputeBudgetInstruction::set_compute_unit_limit(units_consumed_safe);
                all_instructions.push(compute_limit_instruction);

                // Add prioritization fees based on recent fees for this pool
                let prioritization_fees = self
                    .client
                    .rpc
                    .get_recent_prioritization_fees(&[self.pool_address])
                    .await
                    .unwrap_or_else(|e| {
                        println!(
                            "Failed to get prioritization fees, continuing without them: {}",
                            e
                        );
                        vec![]
                    });

                if !prioritization_fees.is_empty() {
                    let mut prioritization_fees_array: Vec<u64> = prioritization_fees
                        .iter()
                        .map(|fee| fee.prioritization_fee)
                        .collect();
                    prioritization_fees_array.sort_unstable();
                    let prioritization_fee = prioritization_fees_array
                        .get(prioritization_fees_array.len() / 2)
                        .cloned();

                    if let Some(fee) = prioritization_fee {
                        println!("Adding prioritization fee: {} micro-lamports per CU", fee);
                        let priority_fee_instruction =
                            ComputeBudgetInstruction::set_compute_unit_price(fee);
                        all_instructions.push(priority_fee_instruction);
                    }
                }
            }

            // Add the swap instructions
            all_instructions.extend(swap_result.instructions.clone());

            // Create final message and transaction
            let final_message = Message::new(&all_instructions, Some(&self.wallet.pubkey()));
            let final_transaction = Transaction::new(&signers, final_message, recent_blockhash);

            // 7. Set transaction config
            let transaction_config = RpcSendTransactionConfig {
                skip_preflight: true,
                preflight_commitment: Some(CommitmentLevel::Confirmed),
                max_retries: Some(1), // We'll handle our own retries
                ..Default::default()
            };

            // 8. Submit transaction with timeout and polling
            println!("Submitting swap transaction...");
            let start_time = Instant::now();

            match self
                .client
                .send_transaction_with_config(&final_transaction, transaction_config)
                .await
            {
                Ok(sig) => {
                    println!("Transaction submitted with signature: {}", sig);

                    // Poll for confirmation with timeout
                    let confirmed = false;
                    while start_time.elapsed() < transaction_timeout {
                        // Wait a bit between polling attempts
                        sleep(Duration::from_millis(1000)).await;

                        // Poll for confirmation
                        let status_result = self.client.rpc.get_signature_statuses(&[sig]).await;
                        match status_result {
                            Ok(response) => {
                                if let Some(Some(status)) = response.value.get(0) {
                                    if let Some(err) = &status.err {
                                        println!("Transaction failed: {:?}", err);
                                        break;
                                    } else if status.confirmation_status.is_some() {
                                        println!("Transaction confirmed!");
                                        println!("Swap transaction successful! Signature: {}", sig);
                                        println!(
                                            "Swapped {} from {} to {}.",
                                            amount as f64
                                                / if from_mint == sol_mint {
                                                    1_000_000_000.0
                                                } else {
                                                    1_000_000.0
                                                },
                                            from_mint,
                                            to_mint
                                        );

                                        // Wait longer for chain state to update completely (at least 5 seconds)
                                        sleep(Duration::from_secs(5)).await;

                                        return Ok(sig);
                                    }
                                }
                            }
                            Err(e) => {
                                // Check if this is a rate limit error
                                if e.to_string().contains("429")
                                    || e.to_string().contains("Too Many Requests")
                                {
                                    println!("Rate limit hit during status check: {}", e);
                                    // Continue polling but wait longer
                                    sleep(Duration::from_millis(2000)).await;
                                } else {
                                    println!("Failed to get transaction status: {}", e);
                                }
                            }
                        }
                    }

                    if !confirmed {
                        println!("Transaction timed out after {:?}", transaction_timeout);
                        // Apply backoff before retrying
                        let backoff =
                            Self::calculate_backoff(attempt, base_backoff_ms, max_backoff_ms);
                        sleep(Duration::from_millis(backoff)).await;
                    }
                }
                Err(e) => {
                    // Check for specific errors
                    let err_string = e.to_string();

                    // Rate limiting errors
                    if err_string.contains("429") || err_string.contains("Too Many Requests") {
                        let backoff =
                            Self::calculate_backoff(attempt, base_backoff_ms, max_backoff_ms);
                        println!("Rate limit hit (429). Retrying in {}ms", backoff);
                        sleep(Duration::from_millis(backoff)).await;
                        continue;
                    }

                    // Token account doesn't exist
                    if err_string.contains("Account does not exist")
                        && to_mint
                            != Pubkey::from_str("So11111111111111111111111111111111111111112")?
                    {
                        println!(
                            "Token account may not exist. Creating token account for {}",
                            to_mint
                        );
                        match self.create_token_account_if_needed(to_mint).await {
                            Ok(_) => {
                                println!("Token account created or verified. Retrying swap...");
                                // Apply a short wait after account creation
                                sleep(Duration::from_millis(1000)).await;
                                continue;
                            }
                            Err(create_err) => {
                                println!("Failed to create token account: {}", create_err);
                                return Err(anyhow::anyhow!(
                                    "Failed to create token account: {}",
                                    create_err
                                ));
                            }
                        }
                    }

                    // Other errors
                    println!("Failed to submit transaction: {}", e);
                    // Apply backoff before retrying
                    let backoff =
                        Self::calculate_backoff(attempt, base_backoff_ms / 2, max_backoff_ms / 2);
                    sleep(Duration::from_millis(backoff)).await;
                }
            }
        }

        Err(anyhow::anyhow!(
            "Failed to execute swap after {} attempts",
            max_retries
        ))
    }

    // New helper method to create token accounts
    async fn create_token_account_if_needed(&self, mint: Pubkey) -> Result<()> {
        use solana_client::rpc_config::RpcSendTransactionConfig;
        use solana_sdk::commitment_config::CommitmentLevel;
        use spl_associated_token_account::instruction::create_associated_token_account;
        use tokio::time::{sleep, Duration, Instant};

        println!("Creating associated token account for mint: {}", mint);

        // First check if token account already exists
        let token_accounts = self
            .client
            .rpc
            .get_token_accounts_by_owner(&self.wallet.pubkey(), TokenAccountsFilter::Mint(mint))
            .await;

        match token_accounts {
            Ok(accounts) if !accounts.is_empty() => {
                println!("Token account already exists");
                return Ok(());
            }
            Err(e) => {
                println!("Error checking for existing token account: {}", e);
                // Continue with creation attempt
            }
            _ => {} // No accounts found, continue with creation
        }

        // Check which token program the mint uses
        let token_program_id = match self.client.rpc.get_account(&mint).await {
            Ok(account) => {
                // Check the owner of the mint account to determine which token program it uses
                let standard_token_program = spl_token::id();
                let token_2022_program = spl_token_2022::id();

                if account.owner == standard_token_program {
                    println!("Mint uses standard SPL Token program");
                    standard_token_program
                } else if account.owner == token_2022_program {
                    println!("Mint uses Token-2022 program");
                    token_2022_program
                } else {
                    println!(
                        "Warning: Mint owner is neither standard Token nor Token-2022 program: {}",
                        account.owner
                    );
                    println!("Defaulting to standard Token program");
                    standard_token_program
                }
            }
            Err(e) => {
                println!(
                    "Could not fetch mint account, defaulting to standard Token program: {}",
                    e
                );
                spl_token::id()
            }
        };

        let instruction = create_associated_token_account(
            &self.wallet.pubkey(), // Funding account
            &self.wallet.pubkey(), // Wallet address
            &mint,                 // Token mint
            &token_program_id,     // Use the correct token program ID
        );

        let max_retries = 5;
        let start_backoff_ms = 1000; // Start with 1 second
        let max_backoff_ms = 15000; // Max 15 seconds

        // Transaction config with preflight disabled to avoid additional RPC calls
        let transaction_config = RpcSendTransactionConfig {
            skip_preflight: true,
            preflight_commitment: Some(CommitmentLevel::Confirmed),
            max_retries: Some(1),
            ..Default::default()
        };

        for attempt in 0..max_retries {
            // Get a fresh blockhash for each attempt
            let recent_blockhash = match self.client.rpc.get_latest_blockhash().await {
                Ok(hash) => hash,
                Err(e) => {
                    // If we can't get a blockhash, apply backoff and retry
                    let backoff =
                        Self::calculate_backoff(attempt, start_backoff_ms, max_backoff_ms);
                    println!(
                        "Failed to get blockhash: {}. Retrying in {}ms (attempt {}/{})",
                        e,
                        backoff,
                        attempt + 1,
                        max_retries
                    );
                    sleep(Duration::from_millis(backoff)).await;
                    continue;
                }
            };

            let tx = Transaction::new_signed_with_payer(
                &[instruction.clone()],
                Some(&self.wallet.pubkey()),
                &[self.wallet.as_ref()],
                recent_blockhash,
            );

            let start_time = Instant::now();
            match self
                .client
                .send_transaction_with_config(&tx, transaction_config)
                .await
            {
                Ok(sig) => {
                    println!("Token account creation transaction submitted: {}", sig);

                    // Poll for confirmation with timeout
                    let confirmation_timeout = Duration::from_secs(30);
                    let poll_interval = Duration::from_millis(1000);
                    let start_poll_time = Instant::now();

                    let mut confirmed = false;
                    while start_poll_time.elapsed() < confirmation_timeout {
                        match self.client.rpc.get_signature_statuses(&[sig]).await {
                            Ok(response) => {
                                if let Some(Some(status)) = response.value.get(0) {
                                    if let Some(err) = &status.err {
                                        println!("Transaction failed: {:?}", err);
                                        break;
                                    } else if status.confirmation_status.is_some() {
                                        println!("Token account created successfully!");
                                        confirmed = true;
                                        break;
                                    }
                                }
                            }
                            Err(e) => {
                                println!("Error checking transaction status: {}", e);
                            }
                        }
                        sleep(poll_interval).await;
                    }

                    if confirmed {
                        return Ok(());
                    } else {
                        println!("Transaction not confirmed within timeout window");
                    }
                }
                Err(e) => {
                    // Check specifically for rate limit errors
                    if e.to_string().contains("429") || e.to_string().contains("Too Many Requests")
                    {
                        let backoff =
                            Self::calculate_backoff(attempt, start_backoff_ms, max_backoff_ms);
                        println!(
                            "Rate limit exceeded (429). Retrying in {}ms (attempt {}/{})",
                            backoff,
                            attempt + 1,
                            max_retries
                        );
                        sleep(Duration::from_millis(backoff)).await;
                    } else if e.to_string().contains("already in use") {
                        // This means the account was actually created
                        println!("Token account already exists");
                        return Ok(());
                    } else {
                        println!("Error sending transaction: {}. Retrying...", e);
                        // Apply shorter backoff for other errors
                        sleep(Duration::from_millis(((attempt + 1) * 500).into())).await;
                    }
                }
            }

            // Add some base delay between attempts to avoid hammering the RPC
            let elapsed = start_time.elapsed().as_millis() as u64;
            if elapsed < 1000 {
                sleep(Duration::from_millis(1000 - elapsed)).await;
            }
        }

        // After all retries
        Err(anyhow::anyhow!(
            "Failed to create token account after {} attempts",
            max_retries
        ))
    }

    // Helper method for calculating exponential backoff with jitter
    fn calculate_backoff(attempt: u32, base_ms: u64, max_ms: u64) -> u64 {
        use rand::thread_rng;
        use rand::Rng;
        let mut rng = thread_rng();

        // Calculate exponential backoff: base * 2^attempt
        let backoff = base_ms * (1 << attempt);

        // Apply max cap
        let capped_backoff = std::cmp::min(backoff, max_ms);

        // Add jitter (±15%)
        let jitter_factor = rng.gen_range(0.85..1.15);
        (capped_backoff as f64 * jitter_factor) as u64
    }

    pub async fn open_position_with_balance_check(
        &mut self,
        lower_price: f64,
        upper_price: f64,
    ) -> Result<()> {
        let mut slippage_tolerance = 100;

        let mut retry_count = 0;
        let max_retries = 10;
        let mut last_error = None;
        let mut wallet_percentage = 0.45;

        while retry_count < max_retries {
            if retry_count > 0 {
                println!(
                    "Retrying position creation (attempt {}/{})",
                    retry_count + 1,
                    max_retries
                );
                // Add a small delay between retries
                tokio::time::sleep(Duration::from_secs(2)).await;
            }
            retry_count += 1;
            let mut wallet_balance = self.get_wallet_balance().await?;
            let mut half_wallet = (wallet_balance as f64 * 0.50) as u64;
            let mut current_amount = (wallet_balance as f64 * wallet_percentage) as u64;
            let invest_percentage = 0.01; // 1% of investment amount for gas
            let min_gas_reserve = 1_000_000; // 0.001 SOL minimum
            let max_gas_reserve = 50_000_000; // 0.05 SOL maximum
            let mut calculated_reserve = (current_amount as f64 * invest_percentage) as u64;
            let mut base_gas_reserve = min_gas_reserve.max(calculated_reserve.min(max_gas_reserve));

            // Add position creation overhead - this covers the cost of creating position accounts
            let position_creation_overhead = 5_000_000; // 0.005 SOL for position creation overhead
            let gas_reserve = base_gas_reserve + position_creation_overhead;
            let mut investment_amount = current_amount.saturating_sub(gas_reserve);

            let whirlpool = self.get_whirlpool().await?;
            let tick_spacing = whirlpool.tick_spacing as i32;

            let price_to_tick_index = |price: f64| -> i32 {
                let raw_tick_index = (price.ln() / 1.0001f64.ln()) as i32;
                (raw_tick_index / tick_spacing) * tick_spacing
            };

            let tick_lower_index = price_to_tick_index(lower_price);
            let tick_upper_index = price_to_tick_index(upper_price);
            let actual_lower_price = 1.0001f64.powi(tick_lower_index);
            let actual_upper_price = 1.0001f64.powi(tick_upper_index);

            self.create_token_account_if_needed(self.token_mint_b)
                .await?;

            let sol_balance = self.get_native_sol_balance().await?;

            println!(
                "Sol Balance:{}\nInvestment Amount:{}",
                sol_balance as f64 / 1_000_000_000.0,
                investment_amount as f64 / 1_000_000_000.0
            );

            if sol_balance < investment_amount + gas_reserve {
                println!("usdc to sol");
                let sol_missing = half_wallet - sol_balance;
                self.swap_tokens(sol_missing, self.token_mint_b, self.token_mint_a, true)
                    .await?;
            } else if sol_balance > half_wallet {
                println!("sol to usdc");
                let excess_sol = sol_balance - half_wallet;
                self.swap_tokens(excess_sol, self.token_mint_a, self.token_mint_b, false)
                    .await?;
            }
            tokio::time::sleep(Duration::from_secs(10)).await;
            let param = IncreaseLiquidityParam::TokenA(investment_amount);

            match open_position_instructions(
                &self.client.rpc,
                self.pool_address,
                actual_lower_price,
                actual_upper_price,
                param,
                Some(slippage_tolerance), // 1% slippage
                Some(self.wallet.pubkey()),
            )
            .await
            {
                Ok(result) => {
                    let mut signers = vec![self.wallet.as_ref()];
                    signers.extend(result.additional_signers.iter().map(|kp| kp as &dyn Signer));
                    let recent_blockhash = self.client.rpc.get_latest_blockhash().await?;
                    let tx = Transaction::new_signed_with_payer(
                        &result.instructions,
                        Some(&self.wallet.pubkey()),
                        &signers,
                        recent_blockhash,
                    );
                    match self
                        .client
                        .send_and_confirm_transaction_with_commitment(
                            &tx,
                            CommitmentLevel::Confirmed,
                        )
                        .await
                    {
                        Ok(sig) => {
                            println!("Opened position successfully. Signature: {}", sig);

                            let (position_address, _) =
                                get_position_address(&result.position_mint)?;
                            let whirlpool_account =
                                self.client.rpc.get_account(&self.pool_address).await?;
                            let _whirlpool = Whirlpool::from_bytes(&whirlpool_account.data)
                                .map_err(|e| {
                                    anyhow::anyhow!("Failed to deserialize Whirlpool: {}", e)
                                })?;

                            // Store correct tick indices for this position
                            let tick_spacing = _whirlpool.tick_spacing as i32; // Convert to i32 for calculations

                            // Convert price to tick index
                            let price_to_tick_index = |price: f64| -> i32 {
                                let raw_tick_index = (price.ln() / 1.0001f64.ln()) as i32;
                                // Round to nearest valid tick based on spacing
                                (raw_tick_index / tick_spacing) * tick_spacing
                            };

                            let tick_lower_index = price_to_tick_index(lower_price);
                            let tick_upper_index = price_to_tick_index(upper_price);

                            // Calculate center price using geometric mean
                            let center_price = (lower_price * upper_price).sqrt();

                            self.position = Some(Position {
                                lower_price,
                                upper_price,
                                center_price,
                                mint_address: result.position_mint,
                                address: position_address,
                                tick_lower_index,
                                tick_upper_index,
                                liquidity: result.quote.liquidity_delta,
                            });

                            // Add a small delay to give time for the position accounts to be fully created and propagated
                            tokio::time::sleep(Duration::from_secs(2)).await;

                            self.display_balances().await?;
                            return Ok(());
                        }
                        Err(e) => {
                            println!("Transaction failed: {}", e);

                            // Check if error is related to TokenMaxExceeded
                            let error_str = e.to_string();
                            if error_str.contains("TokenMaxExceeded")
                                || error_str.contains("0x1781")
                                || error_str.contains("6017")
                            {
                                println!(
                                    "Token maximum exceeded - this usually happens due to price movement."
                                );

                                // On the last attempt, try with significantly higher slippage
                                if retry_count == max_retries - 1 {
                                    println!("Trying one more time with higher slippage tolerance");
                                    slippage_tolerance = 500; // 5% slippage for last attempt
                                }
                            }

                            last_error = Some(anyhow::anyhow!("Failed to open position: {}", e));
                            continue;
                        }
                    };
                }
                Err(e) => {
                    println!(
                        "Failed to get open position instructions: {}",
                        e.to_string()
                    );
                    wallet_percentage = wallet_percentage * 0.9;
                    sleep(Duration::from_millis(5000)).await;
                    continue

                }
            }
        }
        // If we get here, all attempts failed
        Err(last_error.unwrap_or_else(|| {
            anyhow::anyhow!("Failed to open position after {} attempts", max_retries)
        }))
    }

    pub async fn close_position(&mut self) -> Result<(Signature, u128)> {
        if let Some(ref position) = self.position {
            println!("Closing position: {}", position.mint_address);

            let result = close_position_instructions(
                &self.client.rpc,
                position.mint_address,
                Some(1000),
                Some(self.wallet.pubkey()),
            )
            .await
            .map_err(|e| anyhow::anyhow!("Close position instruction error: {}", e))?;

            // Log details about the close position quote to help with debugging
            println!("Position close details:");
            println!(
                "- Token A estimate: {} ({})",
                result.quote.token_est_a,
                result.quote.token_est_a as f64 / 10f64.powi(self.token_mint_a_decimals as i32)
            );
            println!(
                "- Token B estimate: {} ({})",
                result.quote.token_est_b,
                result.quote.token_est_b as f64 / 10f64.powi(self.token_mint_b_decimals as i32)
            );
            println!("- Liquidity delta: {}", result.quote.liquidity_delta);
            println!("- Number of instructions: {}", result.instructions.len());

            // Prepare all signers including any additional ones provided by the SDK
            let mut signers: Vec<&dyn Signer> = vec![self.wallet.as_ref()];

            // Add any additional signers from the SDK result
            if !result.additional_signers.is_empty() {
                println!(
                    "Adding {} additional signers from SDK",
                    result.additional_signers.len()
                );
                signers.extend(result.additional_signers.iter().map(|kp| kp as &dyn Signer));
            }

            let recent_blockhash = self.client.rpc.get_latest_blockhash().await?;
            let tx = Transaction::new_signed_with_payer(
                &result.instructions,
                Some(&self.wallet.pubkey()),
                &signers,
                recent_blockhash,
            );
            let signature = self
                .client
                .send_and_confirm_transaction_with_commitment(&tx, CommitmentLevel::Confirmed)
                .await?;
            println!("Closed position. Signature: {}", signature);

            // Verify that the position is actually closed by checking the position account
            let liquidity = result.quote.liquidity_delta;

            // Wait a moment for the transaction to be fully confirmed on the network
            tokio::time::sleep(Duration::from_secs(3)).await;

            // Try to verify that the position is actually closed
            match self.client.rpc.get_account(&position.mint_address).await {
                Ok(account) => {
                    println!("Warning: Position account still exists after closing! This may indicate a failed closure.");
                    // Try to deserialize to see if it's still a valid position
                    match orca_whirlpools_client::Position::from_bytes(&account.data) {
                        Ok(_) => {
                            println!("Position data still valid - position NOT closed properly!");
                            return Err(anyhow::anyhow!(
                                "Failed to close position: account still exists with valid data"
                            ));
                        }
                        Err(_) => {
                            println!("Position data no longer valid - account may be closing");
                        }
                    }
                }
                Err(e) => {
                    if e.to_string().contains("AccountNotFound") {
                        println!("Position account successfully closed (account not found)");
                    } else {
                        println!("Error checking position account: {}", e);
                    }
                }
            }

            self.position = None;
            self.display_balances().await?;
            Ok((signature, liquidity))
        } else {
            Err(anyhow::anyhow!("No position to close"))
        }
    }

    pub async fn get_position(&self) -> Result<Position> {
        if let Some(ref position) = self.position {
            // Fetch the position data from the blockchain with retry logic
            let orca_position = Retry::spawn(
                ExponentialBackoff::from_millis(500)
                    .max_delay(Duration::from_secs(5))
                    .take(5),
                || async {
                    let position_account = self
                        .client
                        .rpc
                        .get_account(&position.address)
                        .await
                        .map_err(|e: solana_client::client_error::ClientError| {
                            anyhow::anyhow!("Failed to get account: {}", e)
                        })?;

                    let position_data =
                        orca_whirlpools_client::Position::from_bytes(&position_account.data)
                            .map_err(|e| {
                                anyhow::anyhow!("Failed to deserialize position: {}", e)
                            })?;

                    Ok::<orca_whirlpools_client::Position, anyhow::Error>(position_data)
                },
            )
            .await
            .map_err(|e: anyhow::Error| anyhow::anyhow!("Failed to fetch position: {}", e))?;

            // Get the whirlpool data for price calculations
            let whirlpool_account = self
                .client
                .rpc
                .get_account(&self.pool_address)
                .await
                .map_err(|e| anyhow::anyhow!("Failed to fetch whirlpool account: {}", e))?;

            // We don't need the whirlpool object for the current implementation
            let _whirlpool = Whirlpool::from_bytes(&whirlpool_account.data)
                .map_err(|e| anyhow::anyhow!("Failed to deserialize Whirlpool: {}", e))?;

            // Calculate accurate prices using tick indices and sqrt price
            use orca_whirlpools_core::{
                sqrt_price_to_price, tick_index_to_price, tick_index_to_sqrt_price,
            };

            // Method 1: Directly calculate prices from tick indices with correct token decimals
            let lower_price = tick_index_to_price(
                orca_position.tick_lower_index,
                self.token_mint_a_decimals,
                self.token_mint_b_decimals,
            );

            let upper_price = tick_index_to_price(
                orca_position.tick_upper_index,
                self.token_mint_a_decimals,
                self.token_mint_b_decimals,
            );

            // Method 2: Calculate center price using sqrt price calculation
            let position_lower_sqrt_price =
                tick_index_to_sqrt_price(orca_position.tick_lower_index);
            let position_upper_sqrt_price =
                tick_index_to_sqrt_price(orca_position.tick_upper_index);
            let position_center_sqrt_price =
                (position_lower_sqrt_price + position_upper_sqrt_price) / 2;

            let center_price = sqrt_price_to_price(
                position_center_sqrt_price,
                self.token_mint_a_decimals,
                self.token_mint_b_decimals,
            );

            // Convert from orca_whirlpools_client::Position to our custom Position type
            Ok(Position {
                lower_price,
                upper_price,
                center_price,
                mint_address: position.mint_address,
                address: position.address,
                tick_lower_index: orca_position.tick_lower_index as i32,
                tick_upper_index: orca_position.tick_upper_index as i32,
                liquidity: orca_position.liquidity,
            })
        } else {
            Err(anyhow::anyhow!("No active position"))
        }
    }

    async fn display_balances(&self) -> Result<()> {
        let token_a_balance = self.get_balance(self.token_mint_a).await?;
        let token_b_balance = self.get_balance(self.token_mint_b).await?;
        println!(
            "Wallet Balances:\n- Token A ({:?}): {} lamports\n- Token B ({:?}): {} lamports",
            self.token_mint_a, token_a_balance, self.token_mint_b, token_b_balance
        );

        if let Some(ref position) = self.position {
            // Try to get position balances, but don't fail the whole method if it doesn't work
            match close_position_instructions(
                &self.client.rpc,
                position.mint_address,
                Some(100),
                Some(self.wallet.pubkey()),
            )
            .await
            {
                Ok(close_result) => {
                    let token_a_balance = close_result.quote.token_est_a as f64
                        / 10f64.powi(self.token_mint_a_decimals as i32);
                    let token_b_balance = close_result.quote.token_est_b as f64
                        / 10f64.powi(self.token_mint_b_decimals as i32);
                    println!(
                        "Position Balances:\n- Token A ({:?}): {:.6}\n- Token B ({:?}): {:.6}",
                        self.token_mint_a, token_a_balance, self.token_mint_b, token_b_balance
                    );
                }
                Err(e) => {
                    println!("Note: Could not retrieve position balances (this is normal for newly created positions): {}", e);
                    println!(
                        "Position details: Mint: {}, Price range: {}-{}",
                        position.mint_address, position.lower_price, position.upper_price
                    );
                }
            }
        }
        Ok(())
    }

    pub async fn load_position(&mut self, position_mint_address: &str) -> Result<()> {
        if position_mint_address.is_empty() {
            return Ok(());
        }

        println!(
            "Attempting to load position with mint address: {}",
            position_mint_address
        );
        let position_mint = Pubkey::from_str(position_mint_address)?;
        let (position_address, _) = get_position_address(&position_mint)?;

        // Try to fetch the position account with retry logic
        let position_account = match self.client.rpc.get_account(&position_address).await {
            Ok(account) => {
                println!("Position account found. Size: {} bytes", account.data.len());
                account
            }
            Err(e) => {
                println!("Error loading position account: {}", e);
                return Err(anyhow::anyhow!(
                    "Position account not found or inaccessible: {}",
                    e
                ));
            }
        };

        // Try to deserialize the position data
        let position_data =
            match orca_whirlpools_client::Position::from_bytes(&position_account.data) {
                Ok(data) => {
                    println!("Position data loaded successfully");
                    data
                }
                Err(e) => {
                    println!("Error deserializing position data: {}", e);
                    return Err(anyhow::anyhow!(
                        "Failed to deserialize position data: {}",
                        e
                    ));
                }
            };

        // Get the whirlpool data for price calculations
        let _whirlpool = self.get_whirlpool().await?;

        // Calculate prices from tick indices
        use orca_whirlpools_core::{
            sqrt_price_to_price, tick_index_to_price, tick_index_to_sqrt_price,
        };

        let lower_price = tick_index_to_price(
            position_data.tick_lower_index as i32,
            self.token_mint_a_decimals,
            self.token_mint_b_decimals,
        );

        let upper_price = tick_index_to_price(
            position_data.tick_upper_index as i32,
            self.token_mint_a_decimals,
            self.token_mint_b_decimals,
        );

        // Calculate center price
        let position_lower_sqrt_price =
            tick_index_to_sqrt_price(position_data.tick_lower_index as i32);
        let position_upper_sqrt_price =
            tick_index_to_sqrt_price(position_data.tick_upper_index as i32);
        let position_center_sqrt_price =
            (position_lower_sqrt_price + position_upper_sqrt_price) / 2;

        let center_price = sqrt_price_to_price(
            position_center_sqrt_price,
            self.token_mint_a_decimals,
            self.token_mint_b_decimals,
        );

        // Store the position data
        self.position = Some(Position {
            lower_price,
            upper_price,
            center_price,
            mint_address: position_mint,
            address: position_address,
            tick_lower_index: position_data.tick_lower_index as i32,
            tick_upper_index: position_data.tick_upper_index as i32,
            liquidity: position_data.liquidity,
        });

        println!(
            "Loaded existing position: {} (liquidity: {})",
            position_mint, position_data.liquidity
        );
        println!("Position price range: {} - {}", lower_price, upper_price);

        // Display position balance estimates if available
        match close_position_instructions(
            &self.client.rpc,
            position_data.position_mint,
            Some(100),
            Some(self.wallet.pubkey()),
        )
        .await
        {
            Ok(close_result) => {
                let token_a_balance = close_result.quote.token_est_a as f64
                    / 10f64.powi(self.token_mint_a_decimals as i32);
                let token_b_balance = close_result.quote.token_est_b as f64
                    / 10f64.powi(self.token_mint_b_decimals as i32);
                println!(
                    "Position contains approximately:\n- Token A ({:?}): {:.6}\n- Token B ({:?}): {:.6}",
                    self.token_mint_a, token_a_balance, self.token_mint_b, token_b_balance
                );
            }
            Err(e) => {
                println!("Note: Could not retrieve position balances: {}", e);
            }
        }

        Ok(())
    }

    pub async fn get_native_sol_balance(&self) -> Result<u64> {
        match self.client.rpc.get_balance(&self.wallet.pubkey()).await {
            Ok(balance) => Ok(balance),
            Err(e) => Err(anyhow::anyhow!("Failed to get native SOL balance: {}", e)),
        }
    }

    // New method to fetch and load positions for the wallet
    pub async fn load_positions_for_wallet(&mut self) -> Result<bool> {
        println!("Fetching positions for wallet: {}", self.wallet.pubkey());

        // Fetch all positions for the wallet owner
        let positions =
            match fetch_positions_for_owner(&self.client.rpc, self.wallet.pubkey()).await {
                Ok(positions) => {
                    if positions.is_empty() {
                        println!("No positions found for wallet: {}", self.wallet.pubkey());
                        return Ok(false);
                    }

                    println!("Found {} positions or bundles for wallet", positions.len());
                    positions
                }
                Err(e) => {
                    println!("Error fetching positions for wallet: {}", e);
                    return Err(anyhow::anyhow!(
                        "Failed to fetch positions for wallet: {}",
                        e
                    ));
                }
            };

        // Find positions that match our pool_address
        let mut matching_positions = Vec::new();

        for position_or_bundle in positions {
            match position_or_bundle {
                PositionOrBundle::Position(hydrated_position) => {
                    // Check if the position is for our whirlpool
                    if hydrated_position.data.whirlpool == self.pool_address {
                        println!("Found matching position: {}", hydrated_position.address);
                        matching_positions
                            .push((hydrated_position.address, hydrated_position.data));
                    }
                }
                PositionOrBundle::PositionBundle(hydrated_bundle) => {
                    // Check bundled positions
                    for bundled_position in hydrated_bundle.positions {
                        if bundled_position.data.whirlpool == self.pool_address {
                            println!(
                                "Found matching bundled position: {}",
                                bundled_position.address
                            );
                            matching_positions
                                .push((bundled_position.address, bundled_position.data));
                        }
                    }
                }
            }
        }

        if matching_positions.is_empty() {
            println!("No positions found for the specified whirlpool");
            return Ok(false);
        }

        println!(
            "Found {} positions for the specified whirlpool",
            matching_positions.len()
        );

        // Process the first matching position
        let (position_address, position_data) = &matching_positions[0];
        println!("Loading position: {}", position_address);

        // Calculate prices from tick indices
        use orca_whirlpools_core::{
            sqrt_price_to_price, tick_index_to_price, tick_index_to_sqrt_price,
        };

        let lower_price = tick_index_to_price(
            position_data.tick_lower_index,
            self.token_mint_a_decimals,
            self.token_mint_b_decimals,
        );

        let upper_price = tick_index_to_price(
            position_data.tick_upper_index,
            self.token_mint_a_decimals,
            self.token_mint_b_decimals,
        );

        // Calculate center price
        let position_lower_sqrt_price =
            tick_index_to_sqrt_price(position_data.tick_lower_index as i32);
        let position_upper_sqrt_price =
            tick_index_to_sqrt_price(position_data.tick_upper_index as i32);
        let position_center_sqrt_price =
            (position_lower_sqrt_price + position_upper_sqrt_price) / 2;

        let center_price = sqrt_price_to_price(
            position_center_sqrt_price,
            self.token_mint_a_decimals,
            self.token_mint_b_decimals,
        );

        // Store the position data
        self.position = Some(Position {
            lower_price,
            upper_price,
            center_price,
            mint_address: position_data.position_mint,
            address: *position_address,
            tick_lower_index: position_data.tick_lower_index as i32,
            tick_upper_index: position_data.tick_upper_index as i32,
            liquidity: position_data.liquidity,
        });

        println!(
            "Loaded existing position: {} (liquidity: {})",
            position_data.position_mint, position_data.liquidity
        );
        println!("Position price range: {} - {}", lower_price, upper_price);

        // Display position balance estimates if available
        match close_position_instructions(
            &self.client.rpc,
            position_data.position_mint,
            Some(100),
            Some(self.wallet.pubkey()),
        )
        .await
        {
            Ok(close_result) => {
                let token_a_balance = close_result.quote.token_est_a as f64
                    / 10f64.powi(self.token_mint_a_decimals as i32);
                let token_b_balance = close_result.quote.token_est_b as f64
                    / 10f64.powi(self.token_mint_b_decimals as i32);
                println!(
                    "Position contains approximately:\n- Token A ({:?}): {:.6}\n- Token B ({:?}): {:.6}",
                    self.token_mint_a, token_a_balance, self.token_mint_b, token_b_balance
                );
            }
            Err(e) => {
                println!("Note: Could not retrieve position balances: {}", e);
            }
        }

        Ok(true)
    }
}
